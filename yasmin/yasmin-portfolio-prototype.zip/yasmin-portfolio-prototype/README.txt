Yasmin Bajwa: portfolio prototype (Phase 2 + Collection palette and three alternative directions)

Open index.html in any browser. All pages link to each other: Home, Projects,
the four case studies, Contact (contact.html) and the password page
(private-view.html).
logo-compare.html shows the two logo-tile options, (a) colour and (b) ink.

Theme switcher (top-right of every page): COLLECTION is the recommended palette,
taken from the colours in Yasmin's own photographs; ARCHIVE · SALON · CAMPUS are
three alternative directions; MONO is the uncoloured build; EARLIER opens the
previous rounds. Same pages, only colour changes. The choice is kept while you move
between pages; any page can be opened in a direction directly, e.g.
index.html?theme=collection (Archive is ?theme=heritage). The switcher is a prototype
tool only: the Squarespace site will get the one palette that is chosen.

wireframes/  - greyscale wireframes of the same seven pages, for layout approval.
               Start with wireframes/index-wireframes.html. Each file works on its own.

Headings (Instrument Serif) and body text (Inter Tight) load from Google Fonts, so the
pages look right when online. The wireframes have their fonts built in.
